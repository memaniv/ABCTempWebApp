package za.ac.tut.model.bl;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import za.ac.tut.model.entity.Employee;

/**
 *
 * @author MemaniV
 */
@Stateless
public class EmployeeFacade extends AbstractFacade<Employee> implements EmployeeFacadeLocal {

    @PersistenceContext(unitName = "ABCTempEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public EmployeeFacade() {
        super(Employee.class);
    }

    @Override
    public Long determineNumberOfHighTemperatureEmployees() {
        Query query = em.createQuery("SELECT COUNT(e) FROM Employee e WHERE e.tempReading > 38");
        Long cnt = (Long)query.getSingleResult();
        return cnt;
    }

    @Override
    public Long determineNumberOfLowTemperatureEmployees() {
        Query query = em.createQuery("SELECT COUNT(e) FROM Employee e WHERE e.tempReading <= 38");
        Long cnt = (Long)query.getSingleResult();
        return cnt;
    }
    
}
