package za.ac.tut.model.bl;

import javax.ejb.Local;
import za.ac.tut.model.entity.Employee;

/**
 *
 * @author MemaniV
 */
@Local
public interface EmployeeFacadeLocal {

    void create(Employee employee);
    
    Long determineNumberOfHighTemperatureEmployees();
    
    Long determineNumberOfLowTemperatureEmployees();

    /*void edit(Employee employee);

    void remove(Employee employee);

    Employee find(Object id);

    List<Employee> findAll();

    List<Employee> findRange(int[] range);

    int count();*/
    
}
