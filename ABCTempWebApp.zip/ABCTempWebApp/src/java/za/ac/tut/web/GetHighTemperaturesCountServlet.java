package za.ac.tut.web;

import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.bl.EmployeeFacadeLocal;

/**
 *
 * @author MemaniV
 */
public class GetHighTemperaturesCountServlet extends HttpServlet {
    @EJB EmployeeFacadeLocal efl;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Long highCnt = efl.determineNumberOfHighTemperatureEmployees();
        request.setAttribute("highCnt", highCnt);
        
        RequestDispatcher disp = request.getRequestDispatcher("get_high_temp_cnt_outcome.jsp");
        disp.forward(request, response);
    }

}


