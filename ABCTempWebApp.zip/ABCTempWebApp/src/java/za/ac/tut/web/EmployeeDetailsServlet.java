package za.ac.tut.web;

import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.bl.EmployeeFacadeLocal;
import za.ac.tut.model.entity.Employee;

/**
 *
 * @author MemaniV
 */
public class EmployeeDetailsServlet extends HttpServlet {
    @EJB EmployeeFacadeLocal efl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String tempValueStr = request.getParameter("temp_value");
        Double tempValue = Double.parseDouble(tempValueStr);
        String idStr = request.getParameter("id");
        Long id = Long.parseLong(idStr);
        String name = request.getParameter("name");
        
        Employee employee = createEmployee(tempValue, id, name);
        efl.create(employee);
        
        RequestDispatcher disp = request.getRequestDispatcher("capture_employee_details_outcome.jsp");
        disp.forward(request, response);
    }

    private Employee createEmployee(Double tempValue, Long id, String name) {
        Employee emp = new Employee();
        emp.setName(name);
        emp.setId(id);
        emp.setTempReading(tempValue);
        return emp;
    }
}



